package com.example.pixelaquarium

import android.content.Context
import java.util.Calendar

object AquariumStore {
    private const val PREF = "pixel_aquarium_save"
    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    data class State(
        val fish: Int,
        val coins: Int,
        val cleanliness: Int,
        val hunger: Int,
        val streak: Int,
        val lastVisitDay: Int
    )

    fun read(context: Context): State {
        val p = prefs(context)
        return State(
            fish = p.getInt("fish", 1),
            coins = p.getInt("coins", 20),
            cleanliness = p.getInt("cleanliness", 100),
            hunger = p.getInt("hunger", 100),
            streak = p.getInt("streak", 0),
            lastVisitDay = p.getInt("last_day", -1)
        )
    }

    fun save(context: Context, s: State) {
        prefs(context).edit()
            .putInt("fish", s.fish.coerceAtLeast(1))
            .putInt("coins", s.coins.coerceAtLeast(0))
            .putInt("cleanliness", s.cleanliness.coerceIn(0, 100))
            .putInt("hunger", s.hunger.coerceIn(0, 100))
            .putInt("streak", s.streak.coerceAtLeast(0))
            .putInt("last_day", s.lastVisitDay)
            .apply()
        AquariumWidgetProvider.updateAll(context)
    }

    fun markDailyVisit(context: Context): State {
        val s = read(context)
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val stamp = year * 1000 + day
        if (s.lastVisitDay == stamp) return s
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val previousStamp = yesterday.get(Calendar.YEAR) * 1000 + yesterday.get(Calendar.DAY_OF_YEAR)
        val updated = s.copy(
            streak = if (s.lastVisitDay == previousStamp) s.streak + 1 else 1,
            lastVisitDay = stamp,
            hunger = (s.hunger - 12).coerceAtLeast(0),
            cleanliness = (s.cleanliness - 10).coerceAtLeast(0)
        )
        save(context, updated)
        return updated
    }
}
