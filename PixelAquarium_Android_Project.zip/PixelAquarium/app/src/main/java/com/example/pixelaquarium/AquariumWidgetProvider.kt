package com.example.pixelaquarium

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AquariumWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, AquariumWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val s = AquariumStore.read(context)
            val views = RemoteViews(context.packageName, R.layout.aquarium_widget)
            val fishArt = when {
                s.fish >= 4 -> "><(((°>  ><(((°>  ><(((°>"
                s.fish >= 2 -> "><(((°>   ><(((°>"
                else -> "><(((°>"
            }
            views.setTextViewText(R.id.widget_fish, fishArt)
            views.setTextViewText(
                R.id.widget_stats,
                "🐟 ${s.fish} рыб.  •  💧 ${s.cleanliness}%  •  🍽 ${s.hunger}%"
            )
            views.setTextViewText(R.id.widget_hint, "Монеты: ${s.coins}  •  Серия: ${s.streak} дн.")
            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
