package com.example.pixelaquarium

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class PixelTankView(context: Context) : View(context) {
    private val p = Paint().apply { isAntiAlias = false }
    var fishCount = 1
        set(value) { field = value; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = 0xFF0B2945.toInt()
        canvas.drawRect(0f, 0f, w, h, p)
        p.color = 0xFF14547A.toInt()
        canvas.drawRect(0f, h * .28f, w, h, p)
        p.color = 0xFF1D7892.toInt()
        for (i in 0..5) {
            val x = (i * 67f + 22f) % w
            val y = h * (.38f + (i % 3) * .14f)
            canvas.drawRect(x, y, x + 5, y + 5, p)
        }
        val colors = intArrayOf(0xFFFFC857.toInt(), 0xFFFF7B54.toInt(), 0xFFB8F2E6.toInt(), 0xFFCDB4DB.toInt())
        for (i in 0 until fishCount.coerceAtMost(8)) {
            val x = w * (.18f + (i % 4) * .21f)
            val y = h * (.42f + (i / 4) * .25f)
            p.color = colors[i % colors.size]
            canvas.drawRect(x, y, x + 34, y + 17, p)
            canvas.drawRect(x - 9, y + 4, x, y + 13, p)
            p.color = 0xFF10233A.toInt()
            canvas.drawRect(x + 25, y + 4, x + 29, y + 8, p)
        }
        p.color = 0xFFB7E4C7.toInt()
        canvas.drawRect(w * .1f, h * .82f, w * .18f, h * .96f, p)
        canvas.drawRect(w * .16f, h * .75f, w * .23f, h * .96f, p)
        p.color = 0xFF7CC576.toInt()
        canvas.drawRect(w * .78f, h * .8f, w * .84f, h * .96f, p)
        canvas.drawRect(w * .84f, h * .7f, w * .9f, h * .96f, p)
    }
}
