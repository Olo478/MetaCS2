package com.example.pixelaquarium

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var tank: PixelTankView
    private lateinit var stats: TextView
    private lateinit var coins: TextView
    private lateinit var status: TextView
    private var timer: CountDownTimer? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AquariumStore.markDailyVisit(this)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xFF081D32.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                gravity = Gravity.CENTER; setPadding(4, 7, 4, 7)
            }
        root.addView(text("🐠 PIXEL AQUARIUM", 25f, 0xFF9FE7FF.toInt()))
        tank = PixelTankView(this)
        root.addView(tank, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            height = dp(230); weight = 0f
        })
        stats = text("", 15f)
        root.addView(stats)
        coins = text("", 17f, 0xFFFFD166.toInt())
        root.addView(coins)
        status = text("Твой аквариум ждёт!", 14f, 0xFF9FE7FF.toInt())
        root.addView(status)
        addButton("🥣 Кормить рыб (10 секунд)") { startTask("Кормление", 10) { s -> s.copy(hunger = 100, coins = s.coins + 3) } }
        addButton("🧹 Чистить аквариум (30 секунд)") { startTask("Чистка", 30) { s -> s.copy(cleanliness = 100, coins = s.coins + 5) } }
        addButton("🛒 Купить рыбку — 15 монет") { shopBuy() }
        addButton("💰 Продать рыбку — 8 монет") { shopSell() }
        addButton("↻ Обновить аквариум") { refresh() }
        setContentView(root)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
    }

    private fun startTask(name: String, seconds: Int, update: (AquariumStore.State) -> AquariumStore.State) {
        if (busy) return
        busy = true
        root.isEnabled = false
        status.text = "$name: $seconds сек."
        timer = object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(ms: Long) { status.text = "$name: ${(ms + 999) / 1000} сек." }
            override fun onFinish() {
                AquariumStore.save(this@MainActivity, update(AquariumStore.read(this@MainActivity)))
                busy = false
                root.isEnabled = true
                status.text = "$name завершено! Награда получена."
                refresh()
            }
        }.start()
    }

    private fun shopBuy() {
        val s = AquariumStore.read(this)
        if (s.coins < 15) { toast("Не хватает монет!"); return }
        AquariumStore.save(this, s.copy(coins = s.coins - 15, fish = s.fish + 1))
        toast("Новая рыбка куплена!")
        refresh()
    }

    private fun shopSell() {
        val s = AquariumStore.read(this)
        if (s.fish <= 1) { toast("Нельзя продать последнюю рыбку."); return }
        AquariumStore.save(this, s.copy(coins = s.coins + 8, fish = s.fish - 1))
        toast("Рыбка продана за 8 монет.")
        refresh()
    }

    private fun refresh() {
        val s = AquariumStore.read(this)
        tank.fishCount = s.fish
        stats.text = "🐟 Рыб: ${s.fish}     💧 Чистота: ${s.cleanliness}%\n🍽 Сытость: ${s.hunger}%     🔥 Серия: ${s.streak} дн."
        coins.text = "🪙 ${s.coins} монет"
        AquariumWidgetProvider.updateAll(this)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
